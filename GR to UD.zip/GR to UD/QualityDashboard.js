import React, { useEffect, useState, useMemo } from 'react';
import { 
    Box, Typography, Grid, Card, CardContent, Table, TableBody, TableCell, 
    TableHead, TableRow, TableContainer, Paper, Dialog, DialogTitle, 
    DialogContent, IconButton, Chip, CircularProgress, Stack, Divider, 
    TextField, MenuItem, FormControl, Select, InputLabel 
} from '@mui/material';
import { 
    BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, 
    PieChart, Pie, Cell, CartesianGrid 
} from 'recharts';
import CloseIcon from '@mui/icons-material/Close';
import AssignmentIcon from '@mui/icons-material/Assignment';
import QrCodeIcon from '@mui/icons-material/QrCode';
import FactCheckIcon from '@mui/icons-material/FactCheck';
import RuleIcon from '@mui/icons-material/Rule';
import axios from 'axios';

const QualityDashboard = () => {
    const [loading, setLoading] = useState(true);
    
    // Raw Data States
    const [logData, setLogData] = useState([]);
    const [pendingGR, setPendingGR] = useState([]); 
    const [generatedGR, setGeneratedGR] = useState([]); 

    // History Filter States
    const [analysisDate, setAnalysisDate] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
    const [analysisStage, setAnalysisStage] = useState('ALL'); // ALL, LOGGED, GENERATED, INSPECTED, APPROVED, REJECTED

    // Drill-down Dialog State
    const [open, setOpen] = useState(false);
    const [modalConfig, setModalConfig] = useState({ title: '', data: [] });

    // --- 1. DATA FETCHING ---
    useEffect(() => {
        const fetchAllData = async () => {
            try {
                const [resLogs, resPending, resGenerated] = await Promise.all([
                    axios.get('http://localhost:8000/logdata'),
                    axios.get('http://localhost:8000/details'),
                    axios.get('http://localhost:8000/generateddetails')
                ]);
                setLogData(resLogs.data);
                setPendingGR(resPending.data);
                setGeneratedGR(resGenerated.data);
                setLoading(false);
            } catch (error) {
                console.error("Dashboard Fetch Error:", error);
                setLoading(false);
            }
        };
        fetchAllData();
    }, []);

    // --- 2. REAL-TIME BUCKETING ---
    const stats = useMemo(() => {
        const toInspect = generatedGR.filter(i => i.status !== 'Inspected' && i.overall_status !== 'Approved' && i.overall_status !== 'Rejected');
        const toApprove = generatedGR.filter(i => i.status === 'Inspected' && i.overall_status !== 'Approved' && i.overall_status !== 'Rejected');
        const approved = generatedGR.filter(i => i.overall_status === 'Approved');
        const rejected = generatedGR.filter(i => i.overall_status === 'Rejected');

        return { logs: logData, pendingGR, toInspect, toApprove, approved, rejected };
    }, [logData, pendingGR, generatedGR]);

    // --- 3. HISTORICAL DATA PROCESSING ---
    const historyChartData = useMemo(() => {
        if (!analysisDate) return [];

        const year = parseInt(analysisDate.split('-')[0]);
        const month = parseInt(analysisDate.split('-')[1]) - 1; 
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        
        // Helper: Check if date string falls in selected month
        // Note: Using 'created_at' or specific date fields. Ensure backend sends these fields.
        const checkDate = (dateStr) => {
            if (!dateStr) return false;
            const d = new Date(dateStr);
            return d.getFullYear() === year && d.getMonth() === month;
        };

        // Initialize array for every day of the month
        let data = Array.from({ length: daysInMonth }, (_, i) => ({
            day: i + 1,
            Logged: 0,
            Generated: 0,
            Inspected: 0,
            Approved: 0,
            Rejected: 0
        }));

        // Fill Data Buckets
        logData.forEach(item => {
            if (checkDate(item.Entry_Date || item.created_at)) 
                data[new Date(item.Entry_Date || item.created_at).getDate() - 1].Logged++;
        });

        // Combine all GR items for "Generated" count
        [...pendingGR, ...generatedGR].forEach(item => {
            if (checkDate(item.GR_Date || item.created_at)) 
                data[new Date(item.GR_Date || item.created_at).getDate() - 1].Generated++;
        });

        // Inspected/Approved/Rejected from generatedGR
        generatedGR.forEach(item => {
            const dayIndex = new Date(item.updated_at || item.created_at).getDate() - 1;
            if (dayIndex >= 0 && dayIndex < daysInMonth && checkDate(item.updated_at || item.created_at)) {
                if (item.status === 'Inspected' || item.overall_status) data[dayIndex].Inspected++;
                if (item.overall_status === 'Approved') data[dayIndex].Approved++;
                if (item.overall_status === 'Rejected') data[dayIndex].Rejected++;
            }
        });

        return data;
    }, [analysisDate, logData, pendingGR, generatedGR]);

    // Calculate Total for the selected Month based on filter
    const totalMonthlyCount = useMemo(() => {
        return historyChartData.reduce((acc, curr) => {
            if (analysisStage === 'ALL') return acc + curr.Logged + curr.Generated + curr.Approved + curr.Rejected;
            return acc + (curr[analysisStage] || 0);
        }, 0);
    }, [historyChartData, analysisStage]);

    // --- 4. VISUAL DATA PREP ---
    const pipelineData = [
        { name: 'Logbook Entry', count: stats.logs.length, fill: '#607d8b', key: 'LOGS' },
        { name: 'Pending GR', count: stats.pendingGR.length, fill: '#ff9800', key: 'PENDING_GR' },
        { name: 'Pending Insp', count: stats.toInspect.length, fill: '#2196f3', key: 'TO_INSPECT' },
        { name: 'Pending Appr', count: stats.toApprove.length, fill: '#9c27b0', key: 'TO_APPROVE' },
    ];

    const outcomeData = [
        { name: 'Approved', value: stats.approved.length, color: '#4caf50', key: 'APPROVED' },
        { name: 'Rejected', value: stats.rejected.length, color: '#f44336', key: 'REJECTED' },
    ];

    const handleDrillDown = (key, title) => {
        let data = [];
        switch(key) {
            case 'LOGS': data = stats.logs; break;
            case 'PENDING_GR': data = stats.pendingGR; break;
            case 'TO_INSPECT': data = stats.toInspect; break;
            case 'TO_APPROVE': data = stats.toApprove; break;
            case 'APPROVED': data = stats.approved; break;
            case 'REJECTED': data = stats.rejected; break;
            default: data = [];
        }
        setModalConfig({ title, data });
        setOpen(true);
    };

    if (loading) return <CircularProgress sx={{ display: 'block', mx: 'auto', mt: 10 }} />;

    return (
        <Box sx={{ p: 4, bgcolor: '#f8f9fa', minHeight: '100vh' }}>
            <Typography variant="h4" sx={{ mb: 1, fontWeight: 'bold', color: '#1a237e' }}>
                Quality Assurance Dashboard
            </Typography>
            <Typography color="textSecondary" sx={{ mb: 4 }}>
                End-to-End Monitoring: Logbook ➔ GR ➔ Inspection ➔ Approval
            </Typography>

            {/* --- SECTION 1: REAL-TIME OVERVIEW --- */}
            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold', borderLeft: '4px solid #1a237e', pl: 2 }}>
                Real-Time Workflow Status
            </Typography>

            <Grid container spacing={3} sx={{ mb: 4 }}>
                <StatCard title="Logbook Entries" count={stats.logs.length} icon={<AssignmentIcon />} color="#607d8b" onClick={() => handleDrillDown('LOGS', 'Total Logbook Entries')} />
                <StatCard title="Pending GR Gen" count={stats.pendingGR.length} icon={<QrCodeIcon />} color="#ff9800" onClick={() => handleDrillDown('PENDING_GR', 'Items Pending GR Generation')} />
                <StatCard title="Pending Inspection" count={stats.toInspect.length} icon={<FactCheckIcon />} color="#2196f3" onClick={() => handleDrillDown('TO_INSPECT', 'Items Pending Inspection')} />
                <StatCard title="Pending Approval" count={stats.toApprove.length} icon={<RuleIcon />} color="#9c27b0" onClick={() => handleDrillDown('TO_APPROVE', 'Inspected Items Pending Approval')} />
            </Grid>

            <Grid container spacing={3} sx={{ mb: 6 }}>
                <Grid item xs={12} md={8}>
                    <Card sx={{ height: 400, borderRadius: 2, boxShadow: 3 }}>
                        <CardContent sx={{ height: '100%' }}>
                            <Typography variant="subtitle1" fontWeight="bold" sx={{ mb: 2 }}>Current Pipeline Volume</Typography>
                            <ResponsiveContainer width="100%" height="90%">
                                <BarChart data={pipelineData} onClick={(data) => data && handleDrillDown(data.activePayload[0].payload.key, data.activePayload[0].payload.name)}>
                                    <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                    <XAxis dataKey="name" />
                                    <YAxis />
                                    <Tooltip cursor={{fill: 'transparent'}} />
                                    <Bar dataKey="count" radius={[8, 8, 0, 0]} barSize={50}>
                                        {pipelineData.map((entry, i) => <Cell key={i} fill={entry.fill} cursor="pointer" />)}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </CardContent>
                    </Card>
                </Grid>
                <Grid item xs={12} md={4}>
                    <Card sx={{ height: 400, borderRadius: 2, boxShadow: 3 }}>
                        <CardContent sx={{ height: '100%', textAlign: 'center' }}>
                            <Typography variant="subtitle1" fontWeight="bold">Total Outcomes</Typography>
                            <ResponsiveContainer width="100%" height="70%">
                                <PieChart>
                                    <Pie data={outcomeData} cx="50%" cy="50%" innerRadius={70} outerRadius={100} paddingAngle={5} dataKey="value" onClick={(data) => handleDrillDown(data.key, data.name)}>
                                        {outcomeData.map((e, i) => <Cell key={i} fill={e.color} cursor="pointer" />)}
                                    </Pie>
                                    <Tooltip />
                                    <Legend verticalAlign="bottom" />
                                </PieChart>
                            </ResponsiveContainer>
                            <Stack direction="row" justifyContent="center" spacing={3}>
                                <Typography color="success.main" variant="h6">{stats.approved.length} <small>Approved</small></Typography>
                                <Typography color="error.main" variant="h6">{stats.rejected.length} <small>Rejected</small></Typography>
                            </Stack>
                        </CardContent>
                    </Card>
                </Grid>
            </Grid>

            <Divider sx={{ mb: 4 }} />

            {/* --- SECTION 2: MONTHLY THROUGHPUT HISTORY --- */}
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                <Typography variant="h6" sx={{ fontWeight: 'bold', borderLeft: '4px solid #d81b60', pl: 2 }}>
                    Monthly Throughput & History
                </Typography>
                <Box sx={{ display: 'flex', gap: 2 }}>
                    <TextField 
                        type="month" 
                        label="Select Month" 
                        size="small" 
                        value={analysisDate} 
                        onChange={(e) => setAnalysisDate(e.target.value)}
                        InputLabelProps={{ shrink: true }}
                        sx={{ bgcolor: 'white', width: 200 }}
                    />
                    <TextField
                        select
                        label="Filter Stage"
                        size="small"
                        value={analysisStage}
                        onChange={(e) => setAnalysisStage(e.target.value)}
                        sx={{ bgcolor: 'white', width: 150 }}
                    >
                        <MenuItem value="ALL">All Stages</MenuItem>
                        <MenuItem value="Logged">Logged</MenuItem>
                        <MenuItem value="Generated">Generated</MenuItem>
                        <MenuItem value="Inspected">Inspected</MenuItem>
                        <MenuItem value="Approved">Approved (UD)</MenuItem>
                        <MenuItem value="Rejected">Rejected (UD)</MenuItem>
                    </TextField>
                </Box>
            </Box>

            <Card sx={{ height: 450, borderRadius: 2, boxShadow: 3, mb: 4 }}>
                <CardContent sx={{ height: '100%' }}>
                    <Stack direction="row" justifyContent="space-between" sx={{ mb: 2 }}>
                        <Typography variant="subtitle1" fontWeight="bold">
                            Daily Trend: {new Date(analysisDate).toLocaleString('default', { month: 'long', year: 'numeric' })}
                        </Typography>
                        <Chip label={`Total Items: ${totalMonthlyCount}`} color="primary" variant="outlined" />
                    </Stack>
                    
                    <ResponsiveContainer width="100%" height="85%">
                        <BarChart data={historyChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} />
                            <XAxis dataKey="day" label={{ value: 'Day of Month', position: 'insideBottom', offset: -5 }} />
                            <YAxis />
                            <Tooltip cursor={{fill: 'rgba(0,0,0,0.05)'}} />
                            <Legend />
                            
                            {/* Conditional Rendering based on Filter */}
                            {analysisStage === 'ALL' ? (
                                <>
                                    <Bar dataKey="Logged" stackId="a" fill="#607d8b" name="Logged" />
                                    <Bar dataKey="Generated" stackId="a" fill="#ff9800" name="Generated" />
                                    <Bar dataKey="Approved" stackId="a" fill="#4caf50" name="Approved" />
                                    <Bar dataKey="Rejected" stackId="a" fill="#f44336" name="Rejected" />
                                </>
                            ) : (
                                <Bar 
                                    dataKey={analysisStage} 
                                    fill={
                                        analysisStage === 'Logged' ? '#607d8b' :
                                        analysisStage === 'Generated' ? '#ff9800' :
                                        analysisStage === 'Inspected' ? '#2196f3' :
                                        analysisStage === 'Approved' ? '#4caf50' : '#f44336'
                                    } 
                                    name={analysisStage}
                                />
                            )}
                        </BarChart>
                    </ResponsiveContainer>
                </CardContent>
            </Card>

            {/* --- DRILL DOWN DIALOG --- */}
            <Dialog open={open} onClose={() => setOpen(false)} maxWidth="lg" fullWidth>
                <DialogTitle sx={{ display: 'flex', justifyContent: 'space-between', bgcolor: '#f5f5f5' }}>
                    <Typography variant="h6">{modalConfig.title}</Typography>
                    <IconButton onClick={() => setOpen(false)}><CloseIcon /></IconButton>
                </DialogTitle>
                <DialogContent sx={{ p: 0 }}>
                    <TableContainer sx={{ maxHeight: '60vh' }}>
                        <Table stickyHeader size="small">
                            <TableHead>
                                <TableRow>
                                    <TableCell>Ref No</TableCell>
                                    <TableCell>Part Number</TableCell>
                                    <TableCell>Vendor</TableCell>
                                    <TableCell>Quantity</TableCell>
                                    <TableCell>Date</TableCell>
                                    <TableCell>Status</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {modalConfig.data.map((row, i) => (
                                    <TableRow key={i} hover>
                                        <TableCell>{row.Reference_No || row.SL_No}</TableCell>
                                        <TableCell>{row.BEL_Part_Number}</TableCell>
                                        <TableCell>{row.Vendor_Name}</TableCell>
                                        <TableCell>{row.Quantity}</TableCell>
                                        <TableCell>{(row.created_at || row.Entry_Date)?.split('T')[0] || '-'}</TableCell>
                                        <TableCell><StatusChip row={row} /></TableCell>
                                    </TableRow>
                                ))}
                                {modalConfig.data.length === 0 && (
                                    <TableRow><TableCell colSpan={6} align="center">No records found.</TableCell></TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </DialogContent>
            </Dialog>
        </Box>
    );
};

// --- HELPERS ---
const StatCard = ({ title, count, icon, color, onClick }) => (
    <Grid item xs={12} sm={6} md={3}>
        <Card onClick={onClick} sx={{ cursor: 'pointer', borderBottom: `4px solid ${color}`, boxShadow: 2, '&:hover': { boxShadow: 6 } }}>
            <CardContent sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Box>
                    <Typography color="textSecondary" variant="subtitle2" fontWeight="bold">{title}</Typography>
                    <Typography variant="h4" fontWeight="bold" sx={{ color }}>{count}</Typography>
                </Box>
                <Box sx={{ bgcolor: `${color}15`, p: 1.5, borderRadius: '50%', color }}>{icon}</Box>
            </CardContent>
        </Card>
    </Grid>
);

const StatusChip = ({ row }) => {
    let label = 'Pending'; let color = 'default';
    if (row.overall_status === 'Approved') { label = 'Approved'; color = 'success'; }
    else if (row.overall_status === 'Rejected') { label = 'Rejected'; color = 'error'; }
    else if (row.status === 'Inspected') { label = 'Pending Approval'; color = 'secondary'; }
    else if (row.GR_No) { label = 'In Inspection'; color = 'info'; }
    return <Chip label={label} color={color} size="small" variant="outlined" />;
};

export default QualityDashboard;