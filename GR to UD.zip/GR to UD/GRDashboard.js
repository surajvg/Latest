import React, { useEffect, useState, useMemo } from 'react';
import { 
    Box, Typography, Grid, Card, CardContent, Tabs, Tab, TextField, 
    Button, Table, TableBody, TableCell, TableHead, TableRow, TableContainer, 
    Paper, Dialog, DialogTitle, DialogContent, IconButton, Chip, CircularProgress,
    Stack, Divider
} from '@mui/material';
import { 
    PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip as RechartsTooltip, 
    Legend, ResponsiveContainer, CartesianGrid 
} from 'recharts';
import CloseIcon from '@mui/icons-material/Close';
import axios from 'axios';

const GRDashboard = () => {
    const [currentTab, setCurrentTab] = useState(0);
    const [logbookTab, setLogbookTab] = useState(0); // Sub-tab for Logbook Analysis
    
    const [rawPending, setRawPending] = useState([]);
    const [rawGenerated, setRawGenerated] = useState([]);
    const [rawInspected, setRawInspected] = useState([]);
    const [rawLogData, setRawLogData] = useState([]); // New state for /logdata
    const [loading, setLoading] = useState(true);

    // Dialog State
    const [open, setOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState({ name: '', data: [] });

    useEffect(() => {
        fetchDashboardData();
    }, []);

    const fetchDashboardData = async () => {
        try {
            const [resP, resG, resI, resL] = await Promise.all([
                axios.get('http://localhost:8000/details'),
                axios.get('http://localhost:8000/generateddetails'),
                axios.get('http://localhost:8000/inspecteddetails'),
                axios.get('http://localhost:8000/logdata') // Fetching logdata
            ]);
            setRawPending(resP.data);
            setRawGenerated(resG.data);
            setRawInspected(resI.data);
            setRawLogData(resL.data);
            setLoading(false);
        } catch (error) { 
            console.error("Fetch Error:", error); 
            setLoading(false); 
        }
    };

    // --- CENTRALIZED DRILL-DOWN LOGIC ---
    const handleOpenDetail = (key, label) => {
        let data = [];
        switch (key) {
            case 'PENDING':
                data = rawPending;
                break;
            case 'GENERATED':
                data = rawGenerated;
                break;
            case 'TOTAL':
                data = [...rawPending, ...rawGenerated];
                break;
            case 'INSPECTED':
                data = rawInspected;
                break;
            default:
                data = [];
        }
        setSelectedCategory({ name: label, data });
        setOpen(true);
    };

    // --- CHART DATA HELPERS ---
    const chartData = useMemo(() => [
        { name: 'Yet to Generate', value: rawPending.length, color: '#9e9e9e', key: 'PENDING' },
        { name: 'Generated', value: rawGenerated.length, color: '#0088FE', key: 'GENERATED' },
        { name: 'Inspected', value: rawInspected.length, color: '#00C49F', key: 'INSPECTED' },
    ], [rawPending, rawGenerated, rawInspected]);

    // Aggregate Vendor Data for "Yet to Generate" Graph
    const pendingVendorData = useMemo(() => {
        const counts = {};
        rawPending.forEach(item => {
            const vendor = item.Vendor_Name || 'Unknown';
            counts[vendor] = (counts[vendor] || 0) + (Number(item.Quantity) || 0);
        });
        return Object.keys(counts).map(k => ({ name: k, Quantity: counts[k] }));
    }, [rawPending]);

    // Aggregate Type Data for "Generated" Graph
    const generatedTypeData = useMemo(() => {
        const counts = { 'Material Inspection': 0, 'Subcontract Inspection': 0 };
        rawGenerated.forEach(item => {
            const type = item.inspection_type || 'Other';
            if (counts[type] !== undefined) counts[type]++;
            else counts[type] = 1;
        });
        return Object.keys(counts).map((k, i) => ({ 
            name: k, 
            value: counts[k], 
            color: i % 2 === 0 ? '#8884d8' : '#82ca9d' 
        }));
    }, [rawGenerated]);

    if (loading) return <CircularProgress sx={{ m: '20% auto', display: 'block' }} />;

    return (
        <Box sx={{ p: 4, bgcolor: '#f4f7f9', minHeight: '100vh' }}>
            <Typography variant="h4" sx={{ mb: 3, fontWeight: 'bold', color: '#1a237e' }}>
                GR Graphical Overview
            </Typography>

            <Tabs 
                value={currentTab} 
                onChange={(e, v) => setCurrentTab(v)} 
                sx={{ mb: 4, borderBottom: 1, borderColor: 'divider' }}
            >
                <Tab label="Dashboard Statistics" />
                <Tab label="Logbook Analysis" />
            </Tabs>

            {/* TAB 1: DASHBOARD */}
            {currentTab === 0 && (
                <Grid container spacing={3}>
                    {/* Summary Cards */}
                    <Grid item xs={12} md={4}>
                        <StatCard 
                            title="Yet to Generate" 
                            count={rawPending.length} 
                            color="#9e9e9e" 
                            onClick={() => handleOpenDetail('PENDING', 'Yet to Generate')}
                        />
                    </Grid>
                    <Grid item xs={12} md={4}>
                        <StatCard 
                            title="QR Generated" 
                            count={rawGenerated.length} 
                            color="#0088FE" 
                            onClick={() => handleOpenDetail('GENERATED', 'QR Generated')}
                        />
                    </Grid>
                    <Grid item xs={12} md={4}>
                        <StatCard 
                            title="Total Flow" 
                            count={rawPending.length + rawGenerated.length} 
                            color="#673ab7" 
                            onClick={() => handleOpenDetail('TOTAL', 'Total Combined Flow')}
                        />
                    </Grid>

                    {/* Charts Row */}
                    <Grid item xs={12} md={7}>
                        <Card sx={{ height: 480, p: 2, boxShadow: 3 }}>
                            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Workflow Volume (Click Bars)</Typography>
                            <ResponsiveContainer width="100%" height="90%">
                                <BarChart 
                                    data={chartData} 
                                    onClick={(state) => state?.activePayload && handleOpenDetail(state.activePayload[0].payload.key, state.activePayload[0].payload.name)}
                                >
                                    <XAxis dataKey="name" />
                                    <YAxis />
                                    <RechartsTooltip cursor={{ fill: 'rgba(0,0,0,0.05)' }} />
                                    <Bar dataKey="value" style={{ cursor: 'pointer' }}>
                                        {chartData.map((e, i) => <Cell key={i} fill={e.color} />)}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </Card>
                    </Grid>
                    <Grid item xs={12} md={5}>
                        <Card sx={{ height: 480, p: 2, boxShadow: 3 }}>
                            <Typography variant="h6" sx={{ mb: 2, fontWeight: 'bold' }}>Status Distribution</Typography>
                            <ResponsiveContainer width="100%" height="90%">
                                <PieChart>
                                    <Pie 
                                        data={chartData} 
                                        dataKey="value" 
                                        innerRadius={70} 
                                        outerRadius={110} 
                                        paddingAngle={5}
                                        onClick={(state) => handleOpenDetail(state.key, state.name)}
                                        style={{ cursor: 'pointer' }}
                                    >
                                        {chartData.map((e, i) => <Cell key={i} fill={e.color} />)}
                                    </Pie>
                                    <RechartsTooltip />
                                    <Legend />
                                </PieChart>
                            </ResponsiveContainer>
                        </Card>
                    </Grid>
                </Grid>
            )}

            {/* TAB 2: LOGBOOK ANALYSIS */}
            {currentTab === 1 && (
                <Paper sx={{ p: 3, minHeight: '80vh' }}>
                    <Stack direction="row" justifyContent="space-between" alignItems="center" sx={{ mb: 2 }}>
                        <Typography variant="h5" color="primary" fontWeight="bold">Logbook Detail Analysis</Typography>
                        <Chip label={`Total Log Entries: ${rawLogData.length}`} variant="outlined" />
                    </Stack>
                    
                    <Tabs 
                        value={logbookTab} 
                        onChange={(e, v) => setLogbookTab(v)} 
                        textColor="primary"
                        indicatorColor="primary"
                        sx={{ mb: 3, bgcolor: '#f5f5f5', borderRadius: 1 }}
                    >
                        <Tab label={`GR Yet to Generate (${rawPending.length})`} />
                        <Tab label={`GR Generated (${rawGenerated.length})`} />
                    </Tabs>

                    {/* SUB-TAB 0: YET TO GENERATE */}
                    {logbookTab === 0 && (
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={8}>
                                <TableContainer component={Paper} elevation={2} sx={{ maxHeight: 500 }}>
                                    <Table stickyHeader size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e0e0e0' }}>Ref No</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e0e0e0' }}>Part Number</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e0e0e0' }}>Vendor</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e0e0e0' }}>Qty</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e0e0e0' }}>Batch</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {rawPending.map((row, i) => (
                                                <TableRow key={i} hover>
                                                    <TableCell>{row.Reference_No}</TableCell>
                                                    <TableCell>{row.BEL_Part_Number}</TableCell>
                                                    <TableCell>{row.Vendor_Name}</TableCell>
                                                    <TableCell>{row.Quantity}</TableCell>
                                                    <TableCell>{row.Batch_Lot_No}</TableCell>
                                                </TableRow>
                                            ))}
                                            {rawPending.length === 0 && (
                                                <TableRow><TableCell colSpan={5} align="center">No pending items found.</TableCell></TableRow>
                                            )}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>
                            <Grid item xs={12} md={4}>
                                <Card elevation={2} sx={{ height: 500, p: 2 }}>
                                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>Pending Quantity by Vendor</Typography>
                                    <ResponsiveContainer width="100%" height="90%">
                                        <BarChart data={pendingVendorData} layout="vertical" margin={{ left: 20 }}>
                                            <CartesianGrid strokeDasharray="3 3" />
                                            <XAxis type="number" />
                                            <YAxis dataKey="name" type="category" width={100} style={{ fontSize: '10px' }} />
                                            <RechartsTooltip />
                                            <Bar dataKey="Quantity" fill="#ff9800" barSize={20} />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </Card>
                            </Grid>
                        </Grid>
                    )}

                    {/* SUB-TAB 1: GENERATED */}
                    {logbookTab === 1 && (
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={8}>
                                <TableContainer component={Paper} elevation={2} sx={{ maxHeight: 500 }}>
                                    <Table stickyHeader size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd' }}>Ref No</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd' }}>GR Number</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd' }}>Part Number</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd' }}>Vendor</TableCell>
                                                <TableCell sx={{ fontWeight: 'bold', bgcolor: '#e3f2fd' }}>Type</TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {rawGenerated.map((row, i) => (
                                                <TableRow key={i} hover>
                                                    <TableCell>{row.Reference_No}</TableCell>
                                                    <TableCell>{row.GR_No || '-'}</TableCell>
                                                    <TableCell>{row.BEL_Part_Number}</TableCell>
                                                    <TableCell>{row.Vendor_Name}</TableCell>
                                                    <TableCell>
                                                        <Chip 
                                                            label={row.inspection_type || 'N/A'} 
                                                            size="small" 
                                                            color={row.inspection_type?.includes('Material') ? 'info' : 'secondary'} 
                                                            variant="outlined" 
                                                        />
                                                    </TableCell>
                                                </TableRow>
                                            ))}
                                            {rawGenerated.length === 0 && (
                                                <TableRow><TableCell colSpan={5} align="center">No generated items found.</TableCell></TableRow>
                                            )}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Grid>
                            <Grid item xs={12} md={4}>
                                <Card elevation={2} sx={{ height: 500, p: 2 }}>
                                    <Typography variant="subtitle1" fontWeight="bold" gutterBottom>Inspection Type Distribution</Typography>
                                    <ResponsiveContainer width="100%" height="90%">
                                        <PieChart>
                                            <Pie 
                                                data={generatedTypeData} 
                                                dataKey="value" 
                                                nameKey="name" 
                                                cx="50%" 
                                                cy="50%" 
                                                innerRadius={60} 
                                                outerRadius={100} 
                                                paddingAngle={5}
                                                label
                                            >
                                                {generatedTypeData.map((entry, index) => (
                                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                                ))}
                                            </Pie>
                                            <RechartsTooltip />
                                            <Legend verticalAlign="bottom" height={36}/>
                                        </PieChart>
                                    </ResponsiveContainer>
                                </Card>
                            </Grid>
                        </Grid>
                    )}
                </Paper>
            )}

            {/* DRILL-DOWN DIALOG */}
            <Dialog open={open} onClose={() => setOpen(false)} maxWidth="lg" fullWidth scroll="paper">
                <DialogTitle sx={{ bgcolor: '#1a237e', color: 'white', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Box>
                        <Typography variant="h6">{selectedCategory.name}</Typography>
                        <Typography variant="caption" sx={{ opacity: 0.8 }}>Showing {selectedCategory.data.length} records</Typography>
                    </Box>
                    <IconButton onClick={() => setOpen(false)} sx={{ color: 'white' }}><CloseIcon /></IconButton>
                </DialogTitle>
                <DialogContent dividers sx={{ p: 0 }}>
                    <TableContainer sx={{ maxHeight: '70vh' }}>
                        <Table stickyHeader size="small">
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Ref / SL No</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Part Number</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Vendor</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Quantity</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold', bgcolor: '#f5f5f5' }}>Status</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {selectedCategory.data.length > 0 ? (
                                    selectedCategory.data.map((row, i) => (
                                        <TableRow key={i} hover>
                                            <TableCell>{row.Reference_No || row.SL_No}</TableCell>
                                            <TableCell>{row.BEL_Part_Number}</TableCell>
                                            <TableCell>{row.Vendor_Name}</TableCell>
                                            <TableCell>{row.Quantity}</TableCell>
                                            <TableCell>
                                                <Chip 
                                                    size="small" 
                                                    label={row.overall_status || 'Pending'} 
                                                    color={row.overall_status === 'Approved' ? 'success' : row.overall_status === 'Rejected' ? 'error' : 'default'}
                                                    variant="outlined"
                                                />
                                            </TableCell>
                                        </TableRow>
                                    ))
                                ) : (
                                    <TableRow>
                                        <TableCell colSpan={5} align="center" sx={{ py: 3 }}>No data available for this category.</TableCell>
                                    </TableRow>
                                )}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </DialogContent>
            </Dialog>
        </Box>
    );
};

// Sub-component for individual Stat Cards
const StatCard = ({ title, count, color, onClick }) => (
    <Card 
        onClick={onClick}
        sx={{ 
            borderLeft: `6px solid ${color}`, 
            boxShadow: 2, 
            cursor: 'pointer',
            transition: '0.3s',
            '&:hover': { transform: 'translateY(-5px)', boxShadow: 6, bgcolor: '#fff' }
        }}
    >
        <CardContent>
            <Typography color="textSecondary" variant="overline" sx={{ fontWeight: 'bold', letterSpacing: 1 }}>
                {title}
            </Typography>
            <Typography variant="h3" sx={{ color, fontWeight: 'bold' }}>
                {count}
            </Typography>
            <Typography variant="caption" color="primary" sx={{ display: 'block', mt: 1 }}>
                Click to view details →
            </Typography>
        </CardContent>
    </Card>
);

export default GRDashboard;